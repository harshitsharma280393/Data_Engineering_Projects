Card & Payment Sample Project (scaffolded)
=========================================

Structure:
- adf_pipelines/: sample ADF pipeline JSON templates
- databricks_notebooks/: PySpark notebooks (as .py scripts) for ingestion & transformations
- configs/: YAML configuration files used by notebooks
- sql/: DDL and DML scripts for warehouse
- docs/: documentation and runbooks

How to run (local/test):
1. Edit configs/ingest_config.yml to set landing and curated paths.
2. Run databricks_notebooks/card_transactions_ingest.py via Databricks Job or locally with pyspark.
3. Use ADF pipeline templates to create pipelines that orchestrate copy & Databricks job runs.

Generated: 2025-09-29T18:23:26.137519
