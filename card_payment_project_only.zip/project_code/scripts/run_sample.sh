#!/bin/bash
echo "Simulated run script for card payment sample project"
echo "Set CONFIG_PATH if needed, e.g. export CONFIG_PATH=configs/ingest_config.yml"
python3 databricks_notebooks/card_transactions_ingest.py
